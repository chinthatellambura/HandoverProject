function shadowState = shadowing_corridor(cfg, bs, ue, shadowState, ueX_prev, ueY_prev, ueX_curr, ueY_curr)
%SHADOWING_CORRIDOR Spatially correlated shadowing update for road corridor
%
%   shadowState = SHADOWING_CORRIDOR(cfg, bs, ue, shadowState, ...
%       ueX_prev, ueY_prev, ueX_curr, ueY_curr)
%
% Inputs:
%   cfg         : configuration struct
%   bs          : base-station struct from gen_bs_layout_corridor()
%   ue          : UE struct from gen_ue_trajectory_corridor()
%   shadowState : struct holding current shadowing values and metadata
%                 If empty ([]), the function initializes the shadowing state.
%   ueX_prev    : previous UE x positions [K x 1]
%   ueY_prev    : previous UE y positions [K x 1]
%   ueX_curr    : current UE x positions [K x 1]
%   ueY_curr    : current UE y positions [K x 1]
%
% Output:
%   shadowState : updated shadowing state with fields:
%       .value_dB       [K x N] current shadowing values in dB
%       .sigma_dB       shadowing std. dev.
%       .corrDist_m     decorrelation distance
%       .initialized    logical flag
%
% Description:
%   This function implements a lightweight spatially correlated shadowing
%   process for each UE-BS link. Unlike the Milestone 1 toy simulator,
%   where shadowing was regenerated independently at each measurement
%   update, this function updates shadowing as a correlated random process
%   based on UE displacement. This yields smoother, more physically
%   meaningful large-scale signal evolution along the road corridor.
%
% Model:
%   For each UE-BS link, the shadowing value is updated using an
%   exponentially correlated first-order model:
%
%       X_new = rho .* X_old + sqrt(1 - rho.^2) .* W
%
%   where:
%       - X_old is the previous shadowing value,
%       - W is zero-mean Gaussian innovation with std sigma_dB,
%       - rho = exp(-Delta_d / d_corr),
%       - Delta_d is the UE displacement over the update interval,
%       - d_corr is the shadowing decorrelation distance.
%
% Notes:
%   - The same displacement-based rho is applied across all BS links for a
%     given UE over one update step.
%   - This is a system-level abstraction; it is intentionally lightweight.
%   - If shadowState is empty, the function initializes shadowing values.

%% -------------------------
% 1) Basic checks
%% -------------------------
K = ue.numUE;
N = bs.numBS;

sigma_dB = cfg.channel.shadowingStd_dB;
dCorr_m = cfg.channel.shadowCorrDist_m;

if nargin < 4
    error('Not enough input arguments.');
end

if isempty(shadowState)
    %% -------------------------
    % 2) Initialization mode
    %% -------------------------
    shadowState.value_dB = sigma_dB * randn(K, N);
    shadowState.sigma_dB = sigma_dB;
    shadowState.corrDist_m = dCorr_m;
    shadowState.initialized = true;
    return;
end

%% -------------------------
% 3) Input size validation
%% -------------------------
ueX_prev = ueX_prev(:);
ueY_prev = ueY_prev(:);
ueX_curr = ueX_curr(:);
ueY_curr = ueY_curr(:);

if numel(ueX_prev) ~= K || numel(ueY_prev) ~= K || ...
   numel(ueX_curr) ~= K || numel(ueY_curr) ~= K
    error('UE position vectors must all have length K = ue.numUE.');
end

if ~isfield(shadowState, 'value_dB') || ~isequal(size(shadowState.value_dB), [K, N])
    error('shadowState.value_dB must have size [K x N].');
end

%% -------------------------
% 4) UE displacement over current step
%% -------------------------
delta_d = sqrt((ueX_curr - ueX_prev).^2 + (ueY_curr - ueY_prev).^2);  % [K x 1]

% Displacement-based correlation coefficient per UE
rho = exp(-delta_d / dCorr_m);   % [K x 1]
rho = min(max(rho, 0), 1);

%% -------------------------
% 5) Correlated shadowing update
%% -------------------------
X_old = shadowState.value_dB;
X_new = zeros(K, N);

for k = 1:K
    innovation = sigma_dB * randn(1, N);
    X_new(k, :) = rho(k) * X_old(k, :) + sqrt(1 - rho(k)^2) * innovation;
end

%% -------------------------
% 6) Write updated state
%% -------------------------
shadowState.value_dB = X_new;
shadowState.sigma_dB = sigma_dB;
shadowState.corrDist_m = dCorr_m;
shadowState.initialized = true;

end