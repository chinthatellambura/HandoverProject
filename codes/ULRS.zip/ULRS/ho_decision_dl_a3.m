function hoState = ho_decision_dl_a3(cfg, bs, ue, hoState, measMatrix_dBm, servingBS, t)
%HO_DECISION_DL_A3 Conventional DL-RS-based A3 handover decision logic
%
%   hoState = HO_DECISION_DL_A3(cfg, bs, ue, hoState, ...
%       measMatrix_dBm, servingBS, t)
%
% Inputs:
%   cfg            : configuration struct
%   bs             : BS struct
%   ue             : UE struct
%   hoState        : handover-decision state struct; if empty, initializes
%   measMatrix_dBm : [K x N] filtered DL measurement matrix
%                    (typically measState.lastValid_dBm from dl_rs_measurement)
%   servingBS      : [K x 1] current serving BS index per UE
%   t              : current simulation time [s]
%
% Output:
%   hoState        : updated handover-decision state with fields:
%       .tttCounter_s        [K x 1] accumulated TTT time per UE
%       .trackedCandidateBS  [K x 1] candidate BS currently under TTT tracking
%       .bestCandidateBS     [K x 1] best candidate BS at current decision
%       .triggeredNow        [K x 1] logical flag: HO trigger occurred now
%       .targetBS            [K x 1] target BS for newly triggered HO
%       .servMetric_dBm      [K x 1] serving measurement used in decision
%       .candMetric_dBm      [K x 1] candidate measurement used in decision
%       .condHolds           [K x 1] logical flag: A3-like condition true
%       .initialized         logical
%
% Description:
%   This function implements the conventional DL-RS-based A3 handover
%   trigger to serve as the baseline for comparison with the UL-RS-based
%   proposed method. For each UE:
%       1) the best non-serving candidate BS is identified from filtered
%          DL measurements,
%       2) the A3-like condition is evaluated,
%       3) a TTT counter is accumulated while the same candidate remains
%          favorable and the condition holds,
%       4) a handover trigger is declared when the condition persists for
%          at least cfg.ho.TTT_s and the candidate exceeds a minimum
%          usability threshold.
%
% Trigger rule:
%   Let M_serv be the filtered DL measurement of the serving BS and M_cand
%   be that of the best non-serving candidate BS. A trigger is declared if:
%
%       M_cand >= M_serv + A3offset
%
%   and the above condition holds continuously for at least TTT, and:
%
%       M_cand >= minTargetDLRSRP
%
% Notes:
%   - This function mirrors ho_decision_ulrs_a3() as closely as possible so
%     that the comparison between UL-RS and DL-based baseline remains fair.
%   - It only makes the trigger decision; HO execution is handled by the
%     same generic execution block used by the UL-RS simulator.

%% -------------------------
% 1) Basic dimensions
%% -------------------------
K = ue.numUE;
N = bs.numBS;

if ~isequal(size(measMatrix_dBm), [K, N])
    error('measMatrix_dBm must have size [K x N].');
end

servingBS = servingBS(:);
if numel(servingBS) ~= K
    error('servingBS must have length K = ue.numUE.');
end

% Use dedicated DL threshold if available, otherwise reuse generic one
A3offset_dB = cfg.ho.A3offset_dB;
TTT_s = cfg.ho.TTT_s;

if isfield(cfg.ho, 'minTargetDLRSRP_dBm')
    minTargetDLRSRP_dBm = cfg.ho.minTargetDLRSRP_dBm;
else
    minTargetDLRSRP_dBm = cfg.ho.minTargetULRSRP_dBm;
end

dt = cfg.sim.dt;

%% -------------------------
% 2) Initialization
%% -------------------------
if isempty(hoState)
    hoState.tttCounter_s       = zeros(K,1);
    hoState.trackedCandidateBS = zeros(K,1);
    hoState.bestCandidateBS    = zeros(K,1);

    hoState.triggeredNow       = false(K,1);
    hoState.targetBS           = zeros(K,1);

    hoState.servMetric_dBm     = -inf(K,1);
    hoState.candMetric_dBm     = -inf(K,1);
    hoState.condHolds          = false(K,1);

    hoState.lastDecisionTime_s = t;
    hoState.initialized        = true;
end

%% -------------------------
% 3) Reset one-step output fields
%% -------------------------
hoState.triggeredNow(:) = false;
hoState.targetBS(:) = 0;
hoState.bestCandidateBS(:) = 0;
hoState.servMetric_dBm(:) = -inf;
hoState.candMetric_dBm(:) = -inf;
hoState.condHolds(:) = false;

%% -------------------------
% 4) UE-wise decision logic
%% -------------------------
for k = 1:K
    s = servingBS(k);

    if s < 1 || s > N
        error('servingBS(%d) is out of valid range.', k);
    end

    % Serving measurement
    M_serv = measMatrix_dBm(k, s);
    hoState.servMetric_dBm(k) = M_serv;

    % Candidate search among non-serving BSs
    candVals = measMatrix_dBm(k, :);
    candVals(s) = -inf;

    % Future extension point for RAT filtering / policy masking

    [M_cand, c] = max(candVals);
    hoState.bestCandidateBS(k) = c;
    hoState.candMetric_dBm(k) = M_cand;

    % No valid candidate or serving metric => reset TTT state
    if ~isfinite(M_serv) || ~isfinite(M_cand) || c < 1 || c > N
        hoState.tttCounter_s(k) = 0;
        hoState.trackedCandidateBS(k) = 0;
        continue;
    end

    % DL A3-like trigger + minimum candidate usability
    condA3 = (M_cand >= M_serv + A3offset_dB);
    condUsable = (M_cand >= minTargetDLRSRP_dBm);
    cond = condA3 && condUsable;

    hoState.condHolds(k) = cond;

    if cond
        % If the candidate changed while building TTT, restart TTT
        if hoState.trackedCandidateBS(k) ~= 0 && hoState.trackedCandidateBS(k) ~= c
            hoState.tttCounter_s(k) = 0;
        end

        hoState.trackedCandidateBS(k) = c;
        hoState.tttCounter_s(k) = hoState.tttCounter_s(k) + dt;

        if hoState.tttCounter_s(k) >= TTT_s
            hoState.triggeredNow(k) = true;
            hoState.targetBS(k) = c;

            % Reset TTT state after trigger
            hoState.tttCounter_s(k) = 0;
            hoState.trackedCandidateBS(k) = 0;
        end
    else
        % Condition broken
        hoState.tttCounter_s(k) = 0;
        hoState.trackedCandidateBS(k) = 0;
    end
end

%% -------------------------
% 5) Bookkeeping
%% -------------------------
hoState.lastDecisionTime_s = t;

end