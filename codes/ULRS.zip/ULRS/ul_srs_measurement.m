function measState = ul_srs_measurement(cfg, bs, ue, measState, ueX, ueY, shadowState, fastState, t)
%UL_SRS_MEASUREMENT Mixed-scenario UL-SRS measurements

K = ue.numUE;
N = bs.numBS;

ueX = ueX(:);
ueY = ueY(:);

Ptx_dBm = cfg.ue.txPower_dBm;
Tsrs_s = cfg.srs.periodicity_s;
filterType = lower(string(cfg.srs.filterType));
measNoiseStd_dB = cfg.channel.measNoiseStd_dB;

enableBeamGain = cfg.channel.enableBeamGain;
beamGainMean_dB = cfg.channel.beamGainMean_dB;
beamGainStd_dB = cfg.channel.beamGainStd_dB;
beamUpdatePeriod_s = cfg.channel.beamUpdatePeriod_s;

if isempty(measState)
    measState.raw_dBm = -inf(K, N);
    measState.filt_dBm = -inf(K, N);
    measState.lastValid_dBm = -inf(K, N);
    measState.lastSrsTime_s = -inf(K,1);
    measState.numSrsTx = zeros(K,1);
    measState.beamGain_dB = zeros(K,N);
    measState.lastBeamUpdate_s = -inf;
    measState.initialized = true;
end

if enableBeamGain && (t - measState.lastBeamUpdate_s >= beamUpdatePeriod_s)
    measState.lastBeamUpdate_s = t;
    measState.beamGain_dB = beamGainMean_dB + beamGainStd_dB * randn(K, N);
elseif ~enableBeamGain
    measState.beamGain_dB = zeros(K, N);
end

doSrs = (t - measState.lastSrsTime_s) >= Tsrs_s;
idxUE = find(doSrs).';

if isempty(idxUE)
    return;
end

measState.lastSrsTime_s(doSrs) = t;
measState.numSrsTx(doSrs) = measState.numSrsTx(doSrs) + 1;

Xshadow_dB = shadowState.value_dB;
Ffast_dB = fastState.value_dB;
Gbeam_dB = measState.beamGain_dB;

for k = idxUE
    for b = 1:N
        dx = bs.x(b) - ueX(k);
        dy = bs.y(b) - ueY(k);
        d2D_m = sqrt(dx^2 + dy^2);

        rat_b = upper(string(bs.rat(b)));
        switch rat_b
            case "NR"
                cfgTmp = cfg;
                cfgTmp.radio.fcGHz = bs.fcGHz(b);
                PL_dB = pathloss_nr_uma(d2D_m, cfgTmp);
            case "LTE"
                cfgTmp = cfg;
                cfgTmp.radio.lteFcGHz = bs.fcGHz(b);
                PL_dB = pathloss_lte_uma(d2D_m, cfgTmp);
            otherwise
                error('Unsupported BS RAT label: %s', rat_b);
        end

        Nmeas_dB = measNoiseStd_dB * randn();

        measState.raw_dBm(k,b) = ...
            Ptx_dBm ...
            - PL_dB ...
            - Xshadow_dB(k,b) ...
            + Ffast_dB(k,b) ...
            + Gbeam_dB(k,b) ...
            + Nmeas_dB;
    end
end

switch filterType
    case "ema"
        alpha = cfg.srs.emaAlpha;
        for k = idxUE
            oldFilt = measState.filt_dBm(k,:);
            rawNow  = measState.raw_dBm(k,:);
            noPrev = isinf(oldFilt);
            newFilt = oldFilt;
            newFilt(noPrev) = rawNow(noPrev);
            newFilt(~noPrev) = alpha * rawNow(~noPrev) + (1 - alpha) * oldFilt(~noPrev);
            measState.filt_dBm(k,:) = newFilt;
        end
    otherwise
        error('Only EMA filter retained in v2.');
end

measState.lastValid_dBm(idxUE,:) = measState.filt_dBm(idxUE,:);

end