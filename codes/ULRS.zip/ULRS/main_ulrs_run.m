%% MAIN SCRIPT: UL RS-based HO simulation and speed-sweep plots
% This script assumes all helper functions are in the same folder.
% Running this file will:
%   1) load the NR->NR urban macro corridor configuration
%   2) run the speed sweep over multiple random seeds
%   3) generate the main report-facing plots
%
% Author: Milestone 2 UL-RS simulator

clear; clc; close all;

%% -------------------------
% 1) Load configuration
%% -------------------------
cfg = config_ulrs_nr_to_nr_uma();

% Optional: adjust configuration here if needed
cfg.plot.saveFigures = false;     % set true if you want plots saved
cfg.plot.outputDir = 'results';

% Monte Carlo settings
cfg.mc.numSeeds = 10;
cfg.mc.seedList = 1:cfg.mc.numSeeds;

% Speed sweep for report figures
cfg.mobility.speedSet_kmh = [3 10 20 30 50 70 90];

% Default SRS periodicity for this experiment
cfg.srs.periodicity_s = 0.02;

%% -------------------------
% 2) Run speed sweep
%% -------------------------
fprintf('=============================================\n');
fprintf('Running UL RS-based HO speed sweep...\n');
fprintf('Scenario: %s\n', cfg.scenario.description);
fprintf('Speeds [km/h]: %s\n', num2str(cfg.mobility.speedSet_kmh));
fprintf('Monte Carlo seeds: %d\n', cfg.mc.numSeeds);
fprintf('=============================================\n');

results = run_sweep_speed(cfg);

fprintf('\nDone.\n');
fprintf('Average HO probability:\n');
disp(results.mean.HOProbability.');

fprintf('Average mean HO count:\n');
disp(results.mean.meanHOCount.');

fprintf('Average outage probability:\n');
disp(results.mean.outageProbability.');

%% -------------------------
% 3) Generate plots
%% -------------------------
plot_ulrs_vs_speed(results, cfg);

%% -------------------------
% 4) Optional: show summary table in command window
%% -------------------------
summaryTable = table( ...
    results.speed_kmh, ...
    results.mean.HOProbability, ...
    results.mean.meanHOCount, ...
    results.mean.outageProbability, ...
    results.std.HOProbability, ...
    results.std.meanHOCount, ...
    results.std.outageProbability, ...
    'VariableNames', { ...
    'Speed_kmh', ...
    'HOProbability_Mean', ...
    'MeanHOCount_Mean', ...
    'OutageProbability_Mean', ...
    'HOProbability_Std', ...
    'MeanHOCount_Std', ...
    'OutageProbability_Std'});

disp('Summary of speed-sweep results:');
disp(summaryTable);

%% -------------------------
% 5) Optional: save MATLAB results
%% -------------------------
save('ulrs_speed_sweep_results.mat', 'cfg', 'results', 'summaryTable');

fprintf('\nResults saved to ulrs_speed_sweep_results.mat\n');