function plot_compare_ulrs_vs_dl_v2(resultsUL, resultsDL, cfg)

x = resultsUL.speed_kmh;

%==========================================================================
figure;
errorbar(x, resultsDL.mean.HOProbability, resultsDL.std.HOProbability, '-s', 'LineWidth', 1.4); hold on;
errorbar(x, resultsUL.mean.HOProbability, resultsUL.std.HOProbability, '-o', 'LineWidth', 1.4);
grid on;
xlabel('UE speed [km/h]');
ylabel('HO probability');
title(['UL-RS vs DL baseline: HO probability (' cfg.scenario.name ')']);
legend('DL baseline','UL-RS proposed','Location','best');

figure;
plot(x, resultsDL.mean.HOProbability, '-s', 'LineWidth', 1.5,'MarkerSize', 10); hold on;
plot(x, resultsUL.mean.HOProbability, '-o', 'LineWidth', 1.5,'MarkerSize', 10);
grid on;
xlabel('UE speed [km/h]','Interpreter','Latex');
ylabel('HO probability','Interpreter','Latex');
% title(['UL-RS vs DL baseline: HO probability (' cfg.scenario.name ')']);
legend('DL baseline','UL-RS proposed','Location','best', 'Interpreter','Latex');
set(gcf, 'Color', 'w'); set(gca, 'FontSize', 12);



%==========================================================================
figure;
errorbar(x, resultsDL.mean.meanHOCount, resultsDL.std.meanHOCount, '-s', 'LineWidth', 1.4); hold on;
errorbar(x, resultsUL.mean.meanHOCount, resultsUL.std.meanHOCount, '-o', 'LineWidth', 1.4);
grid on;
xlabel('UE speed [km/h]');
ylabel('Mean successful HO count per UE');
title(['UL-RS vs DL baseline: Mean HO count (' cfg.scenario.name ')']);
legend('DL baseline','UL-RS proposed','Location','best');

figure;
plot(x, resultsDL.mean.meanHOCount, '-s', 'LineWidth', 1.5,'MarkerSize', 10); hold on;
plot(x, resultsUL.mean.meanHOCount, '-o', 'LineWidth', 1.5,'MarkerSize', 10);
grid on;
xlabel('UE speed [km/h]', 'Interpreter','Latex');
ylabel('Mean successful HO count per UE', 'Interpreter','Latex');
% title(['UL-RS vs DL baseline: Mean HO count (' cfg.scenario.name ')']);
legend('DL baseline','UL-RS proposed','Location','best', 'Interpreter','Latex');
set(gcf, 'Color', 'w'); set(gca, 'FontSize', 12);


%==========================================================================
figure;
errorbar(x, resultsDL.mean.outageProbability, resultsDL.std.outageProbability, '-s', 'LineWidth', 1.4); hold on;
errorbar(x, resultsUL.mean.outageProbability, resultsUL.std.outageProbability, '-o', 'LineWidth', 1.4);
grid on;
xlabel('UE speed [km/h]');
ylabel('Outage probability');
title(['UL-RS vs DL baseline: Outage probability (' cfg.scenario.name ')']);
legend('DL baseline','UL-RS proposed','Location','best');

figure;
plot(x, resultsDL.mean.outageProbability, '-s', 'LineWidth', 1.5,'MarkerSize', 10); hold on;
plot(x, resultsUL.mean.outageProbability, '-o', 'LineWidth', 1.5,'MarkerSize', 10);
grid on;
xlabel('UE speed [km/h]', 'Interpreter','Latex');
ylabel('Outage probability', 'Interpreter','Latex');
% title(['UL-RS vs DL baseline: Outage probability (' cfg.scenario.name ')']);
legend('DL baseline','UL-RS proposed','Location','best', 'Interpreter','Latex');
set(gcf, 'Color', 'w'); set(gca, 'FontSize', 12);


%==========================================================================
figure;
errorbar(x, resultsDL.mean.HOsPerMCSim, resultsDL.std.HOsPerMCSim, '-s', 'LineWidth', 1.4); hold on;
errorbar(x, resultsUL.mean.HOsPerMCSim, resultsUL.std.HOsPerMCSim, '-o', 'LineWidth', 1.4);
grid on;
xlabel('UE speed [km/h]');
ylabel('Successful HOs / Monte Carlo simulation');
title(['UL-RS vs DL baseline: HOs per MC simulation (' cfg.scenario.name ')']);
legend('DL baseline','UL-RS proposed','Location','best');


figure;
plot(x, resultsDL.mean.HOsPerMCSim, '-s', 'LineWidth', 1.5,'MarkerSize', 10); hold on;
plot(x, resultsUL.mean.HOsPerMCSim, '-o', 'LineWidth', 1.5,'MarkerSize', 10);
grid on;
xlabel('UE speed [km/h]', 'Interpreter','Latex');
ylabel('Successful HOs/MC simulations', 'Interpreter','Latex');
% title(['UL-RS vs DL baseline: HOs per MC simulation (' cfg.scenario.name ')']);
legend('DL baseline','UL-RS proposed','Location','best', 'Interpreter','Latex');
set(gcf, 'Color', 'w'); set(gca, 'FontSize', 12);


%==========================================================================
figure;
errorbar(x, resultsDL.mean.meanDLReportCount, resultsDL.std.meanDLReportCount, '-s', 'LineWidth', 1.4);
grid on;
xlabel('UE speed [km/h]');
ylabel('Mean DL report count per UE');
title(['DL baseline reporting burden (' cfg.scenario.name ')']);

figure;
plot(x, resultsDL.mean.meanDLReportCount, '-s', 'LineWidth', 1.5,'MarkerSize', 10);
grid on;
xlabel('UE speed [km/h]', 'Interpreter','Latex');
ylabel('Mean DL report count per UE', 'Interpreter','Latex');
title(['DL baseline reporting burden (' cfg.scenario.name ')']);


%==========================================================================
figure;
errorbar(x, resultsDL.mean.meanDLDecisionLatency_s, resultsDL.std.meanDLDecisionLatency_s, '-s', 'LineWidth', 1.4);
grid on;
xlabel('UE speed [km/h]');
ylabel('Mean DL decision latency [s]');
title(['DL baseline decision latency (' cfg.scenario.name ')']);

figure;
plot(x, resultsDL.mean.meanDLDecisionLatency_s, '-s', 'LineWidth', 1.5,'MarkerSize', 10);
grid on;
xlabel('UE speed [km/h]', 'Interpreter','Latex');
ylabel('Mean DL decision latency [s]', 'Interpreter','Latex');
% title(['DL baseline decision latency (' cfg.scenario.name ')']);
set(gcf, 'Color', 'w'); set(gca, 'FontSize', 12);

end