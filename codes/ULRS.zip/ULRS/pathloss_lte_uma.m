function PL_dB = pathloss_lte_uma(d2D_m, cfg)
%PATHLOSS_LTE_UMA 3GPP-inspired LTE Urban Macro pathloss model
%
%   PL_dB = PATHLOSS_LTE_UMA(d2D_m, cfg)
%
% Inputs:
%   d2D_m : 2D distance(s) between UE and BS in meters
%           Can be scalar, vector, or matrix.
%   cfg   : configuration struct
%
% Output:
%   PL_dB : pathloss in dB, same size as d2D_m
%
% Description:
%   This function implements a lightweight LTE Urban Macro (UMa) pathloss
%   abstraction for system-level mobility simulation. It is intended for
%   heterogeneous 4G->5G handover studies and is compatible with the UL-RS
%   simulation architecture.
%
%   The model is standards-inspired and captures the main dependencies on:
%       - carrier frequency,
%       - BS/UE antenna heights,
%       - distance,
%       - LOS / NLOS selection.
%
% Notes:
%   - This is a system-level abstraction, not a full channel model.
%   - A minimum distance is enforced to avoid nonphysical singularities.
%   - If no LTE-specific carrier frequency is given in cfg, the function
%     falls back to cfg.radio.fcGHz.
%
% Suggested configuration fields:
%   cfg.radio.fcGHz                % fallback carrier frequency [GHz]
%   cfg.radio.lteFcGHz             % optional LTE carrier frequency [GHz]
%   cfg.bs.height_m                % BS height [m]
%   cfg.ue.height_m                % UE height [m]
%   cfg.channel.enableLOSModel
%   cfg.channel.forceLOS
%   cfg.channel.forceNLOS          % optional

%% -------------------------
% 1) Read parameters
%% -------------------------
if isfield(cfg.radio, 'lteFcGHz')
    fc_GHz = cfg.radio.lteFcGHz;
else
    fc_GHz = cfg.radio.fcGHz;
end

hBS = cfg.bs.height_m;
hUE = cfg.ue.height_m;

enableLOSModel = cfg.channel.enableLOSModel;
forceLOS = cfg.channel.forceLOS;

forceNLOS = false;
if isfield(cfg.channel, 'forceNLOS')
    forceNLOS = cfg.channel.forceNLOS;
end

%% -------------------------
% 2) Distance sanitization
%% -------------------------
d2D_m = max(d2D_m, 10);   % enforce minimum model distance
d3D_m = sqrt(d2D_m.^2 + (hBS - hUE).^2);

%% -------------------------
% 3) LOS probability model
%% -------------------------
% Use the same lightweight UMa LOS probability structure for consistency.
if forceLOS && forceNLOS
    error('Both forceLOS and forceNLOS cannot be true simultaneously.');
end

if forceLOS
    isLOS = true(size(d2D_m));
elseif forceNLOS
    isLOS = false(size(d2D_m));
elseif enableLOSModel
    pLOS = ones(size(d2D_m));

    idxFar = d2D_m > 18;
    dFar = d2D_m(idxFar);

    pLOS(idxFar) = (18 ./ dFar) + exp(-dFar / 63) .* (1 - 18 ./ dFar);
    pLOS = min(max(pLOS, 0), 1);

    isLOS = rand(size(d2D_m)) < pLOS;
else
    % Conservative first-revision choice
    isLOS = false(size(d2D_m));
end

%% -------------------------
% 4) Breakpoint distance
%% -------------------------
% Standards-inspired breakpoint form for macrocell propagation.
dBP = 4 * hBS * hUE * (fc_GHz * 1e9) / 3e8;  % [m]

%% -------------------------
% 5) LOS pathloss
%% -------------------------
PL_LOS = zeros(size(d2D_m));

idx1 = d2D_m <= dBP;
idx2 = d2D_m > dBP;

PL_LOS(idx1) = 28.0 + 22*log10(d3D_m(idx1)) + 20*log10(fc_GHz);

PL_LOS(idx2) = 28.0 + 40*log10(d3D_m(idx2)) + 20*log10(fc_GHz) ...
    - 9*log10(dBP^2 + (hBS - hUE)^2);

%% -------------------------
% 6) NLOS pathloss
%% -------------------------
% LTE UMa-style NLOS abstraction with frequency and distance dependence.
PL_NLOS_raw = 22.7 + 36.7*log10(d3D_m) + 26*log10(fc_GHz / 2.0);

% Ensure NLOS is not lower than LOS
PL_NLOS = max(PL_LOS, PL_NLOS_raw);

%% -------------------------
% 7) Final regime selection
%% -------------------------
PL_dB = PL_NLOS;
PL_dB(isLOS) = PL_LOS(isLOS);

end