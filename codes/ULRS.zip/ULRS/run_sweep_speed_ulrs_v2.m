function results = run_sweep_speed_ulrs_v2(cfg)

speedSet_kmh = cfg.mobility.speedSet_kmh(:);
numSpeeds = numel(speedSet_kmh);

seedList = cfg.mc.seedList(:);
numSeeds = numel(seedList);

HOProbability_runs = nan(numSpeeds, numSeeds);
meanHOCount_runs = nan(numSpeeds, numSeeds);
outageProbability_runs = nan(numSpeeds, numSeeds);
HOsPerMCSim_runs = nan(numSpeeds, numSeeds);

for i = 1:numSpeeds
    speed_kmh = speedSet_kmh(i);
    for j = 1:numSeeds
        seed = seedList(j);
        [kpi, ~] = main_ulrs_single_run_v2(cfg, speed_kmh, seed);
        HOProbability_runs(i,j) = kpi.HOProbability;
        meanHOCount_runs(i,j) = kpi.meanHOCount;
        outageProbability_runs(i,j) = kpi.outageProbability;
        HOsPerMCSim_runs(i,j) = kpi.HOsPerMCSim;
    end
end

results.speed_kmh = speedSet_kmh;
results.mean.HOProbability = mean(HOProbability_runs, 2, 'omitnan');
results.mean.meanHOCount = mean(meanHOCount_runs, 2, 'omitnan');
results.mean.outageProbability = mean(outageProbability_runs, 2, 'omitnan');
results.mean.HOsPerMCSim = mean(HOsPerMCSim_runs, 2, 'omitnan');

results.std.HOProbability = std(HOProbability_runs, 0, 2, 'omitnan');
results.std.meanHOCount = std(meanHOCount_runs, 0, 2, 'omitnan');
results.std.outageProbability = std(outageProbability_runs, 0, 2, 'omitnan');
results.std.HOsPerMCSim = std(HOsPerMCSim_runs, 0, 2, 'omitnan');

end