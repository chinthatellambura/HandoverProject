function [kpi, simOut] = main_dl_single_run_v2(cfg, speed_kmh, seed)

if nargin < 2 || isempty(speed_kmh)
    speed_kmh = cfg.mobility.defaultSpeed_kmh;
end
if nargin < 3 || isempty(seed)
    seed = cfg.sim.seed;
end

rng(seed);

bs = gen_bs_layout_corridor_v2(cfg);
ue = gen_ue_trajectory_corridor(cfg, speed_kmh);

Nt = cfg.sim.Nt;
dt = cfg.sim.dt;

ueX = ue.x0;
ueY = ue.y0;
ueVx = ue.vx;
ueVy = ue.vy;

shadowState = [];
shadowState = shadowing_corridor(cfg, bs, ue, shadowState, [], [], [], []);

fastState = [];
fastState = fast_variation_abstraction(cfg, bs, ue, fastState);

measState = [];
measState = dl_rs_measurement(cfg, bs, ue, measState, ueX, ueY, ...
    shadowState, fastState, 0);

servingBS = select_serving_bs_initial_v2(cfg, bs, measState.lastValid_dBm, ueX, ueY);

hoState = [];
execState = [];
outageState = [];
pipeState = [];

for n = 1:Nt
    t = (n-1) * dt;

    ueX_prev = ueX;
    ueY_prev = ueY;

    ueX = ueX + ueVx * dt;
    ueY = ueY + ueVy * dt;

    xMin = 0;
    xMax = cfg.layout.roadLength_m;
    yMin = -0.5 * cfg.layout.roadWidth_m;
    yMax = +0.5 * cfg.layout.roadWidth_m;

    hitL = ueX < xMin;
    hitR = ueX > xMax;

    ueVx(hitL) = abs(ueVx(hitL));
    ueX(hitL) = xMin + (xMin - ueX(hitL));

    ueVx(hitR) = -abs(ueVx(hitR));
    ueX(hitR) = xMax - (ueX(hitR) - xMax);

    ueY = min(max(ueY, yMin), yMax);

    shadowState = shadowing_corridor(cfg, bs, ue, shadowState, ...
        ueX_prev, ueY_prev, ueX, ueY);

    fastState = fast_variation_abstraction(cfg, bs, ue, fastState);

    measState = dl_rs_measurement(cfg, bs, ue, measState, ueX, ueY, ...
        shadowState, fastState, t);

    hoState = ho_decision_dl_a3(cfg, bs, ue, hoState, ...
        measState.lastValid_dBm, servingBS, t);

    [pipeState, execTriggerState] = dl_report_pipeline(cfg, ue, pipeState, execState, hoState, t);

    [execState, servingBS, outageState] = ho_execution_ulrs( ...
        cfg, bs, ue, execState, outageState, servingBS, ...
        measState.lastValid_dBm, execTriggerState, t);
end

kpi = compute_ulrs_kpis_v2(cfg, ue, execState, outageState);
kpi.meanDLReportCount = mean(pipeState.numReports);
if sum(pipeState.numDecisionStarts) > 0
    kpi.meanDLDecisionLatency_s = sum(pipeState.accDecisionLatency_s) / sum(pipeState.numDecisionStarts);
else
    kpi.meanDLDecisionLatency_s = NaN;
end

simOut = struct();
simOut.bs = bs;
simOut.ue = ue;
simOut.execState = execState;
simOut.outageState = outageState;
simOut.pipeState = pipeState;
simOut.final.servingBS = servingBS;

end