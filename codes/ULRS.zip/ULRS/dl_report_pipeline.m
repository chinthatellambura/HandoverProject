function [pipeState, execTriggerState] = dl_report_pipeline(cfg, ue, pipeState, execState, hoState, t)
%DL_REPORT_PIPELINE Add report-delay and decision-delay to DL baseline
%
%   [pipeState, execTriggerState] = dl_report_pipeline(cfg, ue, pipeState, ...
%       execState, hoState, t)
%
% This module converts an immediate DL A3 trigger into a realistic
% measurement-report + network-decision pipeline.
%
% Stages:
%   1) UE detects A3+TTT satisfied -> creates measurement report
%   2) report arrives after reportDelay_s
%   3) network makes decision after decisionDelay_s
%   4) only then is HO execution allowed to start
%
% Output execTriggerState has:
%   .triggeredNow [Kx1 logical]
%   .targetBS     [Kx1]

K = ue.numUE;

% Defaults if cfg.dl fields missing
reportDelay_s = 0.03;
decisionDelay_s = 0.01;
if isfield(cfg, 'dl') && isfield(cfg.dl, 'reportDelay_s')
    reportDelay_s = cfg.dl.reportDelay_s;
end
if isfield(cfg, 'dl') && isfield(cfg.dl, 'decisionDelay_s')
    decisionDelay_s = cfg.dl.decisionDelay_s;
end

%% Init
if isempty(pipeState)
    pipeState.isPending = false(K,1);
    pipeState.targetBS = zeros(K,1);
    pipeState.reportReadyTime_s = nan(K,1);
    pipeState.decisionReadyTime_s = nan(K,1);
    pipeState.triggerSourceTime_s = nan(K,1);

    pipeState.numReports = zeros(K,1);
    pipeState.numDecisionStarts = zeros(K,1);
    pipeState.accDecisionLatency_s = zeros(K,1);

    pipeState.initialized = true;
end

%% Reset output
execTriggerState.triggeredNow = false(K,1);
execTriggerState.targetBS = zeros(K,1);

%% Pipeline update
for k = 1:K
    % Step 1: enqueue a report when DL trigger occurs, only if not already pending and not already executing
    if hoState.triggeredNow(k) && ~pipeState.isPending(k) && ~execState.isExecuting(k)
        pipeState.isPending(k) = true;
        pipeState.targetBS(k) = hoState.targetBS(k);
        pipeState.triggerSourceTime_s(k) = t;
        pipeState.reportReadyTime_s(k) = t + reportDelay_s;
        pipeState.decisionReadyTime_s(k) = t + reportDelay_s + decisionDelay_s;
        pipeState.numReports(k) = pipeState.numReports(k) + 1;
    end

    % Step 2: when decision time is reached, release execution trigger
    if pipeState.isPending(k) && (t >= pipeState.decisionReadyTime_s(k)) && ~execState.isExecuting(k)
        execTriggerState.triggeredNow(k) = true;
        execTriggerState.targetBS(k) = pipeState.targetBS(k);

        pipeState.numDecisionStarts(k) = pipeState.numDecisionStarts(k) + 1;
        pipeState.accDecisionLatency_s(k) = pipeState.accDecisionLatency_s(k) + ...
            (t - pipeState.triggerSourceTime_s(k));

        % clear pending pipeline
        pipeState.isPending(k) = false;
        pipeState.targetBS(k) = 0;
        pipeState.reportReadyTime_s(k) = nan;
        pipeState.decisionReadyTime_s(k) = nan;
        pipeState.triggerSourceTime_s(k) = nan;
    end
end

end