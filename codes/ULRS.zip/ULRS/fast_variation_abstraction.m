function fastState = fast_variation_abstraction(cfg, bs, ue, fastState)
%FAST_VARIATION_ABSTRACTION Short-term signal fluctuation model for system-level simulation
%
%   fastState = FAST_VARIATION_ABSTRACTION(cfg, bs, ue, fastState)
%
% Inputs:
%   cfg       : configuration struct
%   bs        : base-station struct
%   ue        : UE struct
%   fastState : struct holding current fast-variation state
%               If empty ([]), the function initializes the state.
%
% Output:
%   fastState : updated fast-variation state with fields:
%       .value_dB        [K x N] current short-term fluctuation values in dB
%       .sigma_dB        standard deviation of fast fluctuation
%       .corrTime_s      temporal correlation time
%       .lastUpdate_dt_s last time-step used in update
%       .initialized     logical flag
%
% Description:
%   This function provides a lightweight system-level abstraction of
%   short-term signal fluctuation. It is not a waveform-level fading model.
%   Instead, it generates temporally correlated zero-mean variations that
%   emulate residual fast channel dynamics affecting UL measurements.
%
% Model:
%   A first-order Gauss-Markov process is used for each UE-BS link:
%
%       F_new = alpha * F_old + sqrt(1 - alpha^2) * W
%
%   where:
%       - W is zero-mean Gaussian innovation with std sigma_dB
%       - alpha = exp(-dt / Tcorr)
%       - dt is the simulation time step
%       - Tcorr is the temporal correlation constant
%
% Notes:
%   - This abstraction is intentionally lightweight for mobility-level
%     studies.
%   - It complements pathloss + correlated shadowing + measurement noise.
%   - It can later be made speed-dependent if desired, but the first
%     implementation keeps one common correlation model for simplicity.

%% -------------------------
% 1) Read parameters
%% -------------------------
K = ue.numUE;
N = bs.numBS;

sigma_dB = cfg.channel.fastFadingStd_dB;
Tcorr_s = cfg.channel.fastFadingCorrTime_s;
dt = cfg.sim.dt;

if Tcorr_s <= 0
    error('cfg.channel.fastFadingCorrTime_s must be positive.');
end

alpha = exp(-dt / Tcorr_s);
alpha = min(max(alpha, 0), 1);

%% -------------------------
% 2) Initialization mode
%% -------------------------
if isempty(fastState)
    fastState.value_dB = sigma_dB * randn(K, N);
    fastState.sigma_dB = sigma_dB;
    fastState.corrTime_s = Tcorr_s;
    fastState.lastUpdate_dt_s = dt;
    fastState.initialized = true;
    return;
end

%% -------------------------
% 3) Validate state size
%% -------------------------
if ~isfield(fastState, 'value_dB') || ~isequal(size(fastState.value_dB), [K, N])
    error('fastState.value_dB must have size [K x N].');
end

%% -------------------------
% 4) Correlated fast-variation update
%% -------------------------
F_old = fastState.value_dB;
innovation = sigma_dB * randn(K, N);

F_new = alpha .* F_old + sqrt(1 - alpha^2) .* innovation;

%% -------------------------
% 5) Write updated state
%% -------------------------
fastState.value_dB = F_new;
fastState.sigma_dB = sigma_dB;
fastState.corrTime_s = Tcorr_s;
fastState.lastUpdate_dt_s = dt;
fastState.initialized = true;

end