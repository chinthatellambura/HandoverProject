function plot_ulrs_vs_speed(results, cfg)
%PLOT_ULRS_VS_SPEED Plot primary UL-RS KPIs versus user speed
%
%   plot_ulrs_vs_speed(results, cfg)
%
% Inputs:
%   results : output struct from run_sweep_speed()
%   cfg     : configuration struct
%
% Description:
%   Generates the first report-facing figures for the revised UL-RS
%   simulator:
%       1) Handover probability vs speed
%       2) Mean handover count vs speed
%       3) Outage probability vs speed
%
% Notes:
%   - Error bars show one standard deviation across Monte Carlo seeds.
%   - Figures are optionally saved if cfg.plot.saveFigures is true.

x = results.speed_kmh;

%% Figure 1: HO probability vs speed
figure;
errorbar(x, results.mean.HOProbability, results.std.HOProbability, ...
    '-o', 'LineWidth', 1.4, 'MarkerSize', 6);
grid on;
xlabel('UE speed [km/h]');
ylabel('Handover probability');
title('UL RS-based HO probability vs user speed');

if cfg.plot.saveFigures
    saveFigureHelper(cfg, 'ulrs_ho_probability_vs_speed');
end

%% Figure 2: Mean HO count vs speed
figure;
errorbar(x, results.mean.meanHOCount, results.std.meanHOCount, ...
    '-o', 'LineWidth', 1.4, 'MarkerSize', 6);
grid on;
xlabel('UE speed [km/h]');
ylabel('Mean HO count per UE');
title('UL RS-based mean HO count vs user speed');

if cfg.plot.saveFigures
    saveFigureHelper(cfg, 'ulrs_mean_ho_count_vs_speed');
end

%% Figure 3: Outage probability vs speed
figure;
errorbar(x, results.mean.outageProbability, results.std.outageProbability, ...
    '-o', 'LineWidth', 1.4, 'MarkerSize', 6);
grid on;
xlabel('UE speed [km/h]');
ylabel('Outage probability');
title('UL RS-based outage probability vs user speed');

if cfg.plot.saveFigures
    saveFigureHelper(cfg, 'ulrs_outage_probability_vs_speed');
end

end

function saveFigureHelper(cfg, baseName)
% Internal helper for saving figures
if ~exist(cfg.plot.outputDir, 'dir')
    mkdir(cfg.plot.outputDir);
end

filePath = fullfile(cfg.plot.outputDir, sprintf('%s.%s', ...
    baseName, cfg.plot.figureFormat));
saveas(gcf, filePath);
end