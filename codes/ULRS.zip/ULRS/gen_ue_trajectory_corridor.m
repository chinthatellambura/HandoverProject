function ue = gen_ue_trajectory_corridor(cfg, speed_kmh)
%GEN_UE_TRAJECTORY_CORRIDOR Generate UE initial states and corridor motion
%
%   ue = GEN_UE_TRAJECTORY_CORRIDOR(cfg, speed_kmh)
%
% Inputs:
%   cfg        : configuration struct
%   speed_kmh  : nominal scenario speed in km/h
%
% Output:
%   ue : struct containing UE initial position, velocity, and metadata
%
% Description:
%   This function generates UEs moving along a road/highway corridor in 2D.
%   The motion is longitudinal along the road, with optional bidirectional
%   traffic. Each UE is assigned a nominal speed plus a small random
%   perturbation, an initial position on the road, and a lane-dependent
%   lateral offset.
%
% Notes:
%   - This function generates initial states only.
%   - Time evolution is handled later in the main simulation loop.
%   - The road centerline is y = 0.
%   - UE altitude is fixed by cfg.ue.height_m.

%% -------------------------
% 1) Inputs and checks
%% -------------------------
if nargin < 2 || isempty(speed_kmh)
    speed_kmh = cfg.mobility.defaultSpeed_kmh;
end

K = cfg.ue.numUE;
roadLen = cfg.layout.roadLength_m;
roadWidth = cfg.layout.roadWidth_m;
numLanes = cfg.layout.numLanes;
hUE = cfg.ue.height_m;

if K < 1
    error('cfg.ue.numUE must be >= 1.');
end
if numLanes < 1
    error('cfg.layout.numLanes must be >= 1.');
end

%% -------------------------
% 2) Speed assignment
%% -------------------------
% Convert km/h to m/s
speedMean_mps = speed_kmh / 3.6;
speedStd_mps  = cfg.mobility.speedStd_kmh / 3.6;

% Ensure non-negative practical speeds
speed_mps = max(0.5, speedMean_mps + speedStd_mps * randn(K,1));

%% -------------------------
% 3) Direction assignment
%% -------------------------
dirMode = lower(string(cfg.mobility.directionMode));

switch dirMode
    case "forward"
        dirSign = ones(K,1);

    case "backward"
        dirSign = -ones(K,1);

    case "bidirectional"
        dirSign = sign(randn(K,1));
        % Avoid zeros from sign(0)
        zeroIdx = (dirSign == 0);
        dirSign(zeroIdx) = 1;

    otherwise
        error('Unknown cfg.mobility.directionMode: %s', cfg.mobility.directionMode);
end

vx = dirSign .* speed_mps;
vy = zeros(K,1);

%% -------------------------
% 4) Initial x positions
%% -------------------------
% Spread users across the corridor to avoid artificial clustering.
x0 = roadLen * rand(K,1);

%% -------------------------
% 5) Initial y positions (lane-based)
%% -------------------------
% Divide road into lanes and place UE near lane centers with small jitter.
laneWidth = roadWidth / numLanes;
laneCenters = zeros(numLanes,1);

for ell = 1:numLanes
    laneCenters(ell) = -roadWidth/2 + (ell - 0.5) * laneWidth;
end

laneIdx = randi(numLanes, K, 1);

% Add small within-lane jitter while keeping UE on the road
laneJitterStd = 0.15 * laneWidth;
y0 = laneCenters(laneIdx) + laneJitterStd * randn(K,1);

% Clamp to road boundaries
y0 = min(max(y0, -roadWidth/2), roadWidth/2);

z0 = hUE * ones(K,1);

%% -------------------------
% 6) UE identifiers and metadata
%% -------------------------
ue.numUE = K;

ue.id = (1:K).';
ue.name = strings(K,1);
for k = 1:K
    ue.name(k) = sprintf('UE_%02d', k);
end

ue.x0 = x0;
ue.y0 = y0;
ue.z0 = z0;

ue.vx = vx;
ue.vy = vy;
ue.vz = zeros(K,1);

ue.speed_mps = speed_mps;
ue.speed_kmh = 3.6 * speed_mps;
ue.direction = dirSign;
ue.laneIndex = laneIdx;

%% -------------------------
% 7) Road and boundary metadata
%% -------------------------
ue.road.xMin = 0;
ue.road.xMax = roadLen;
ue.road.yMin = -roadWidth/2;
ue.road.yMax = +roadWidth/2;
ue.road.numLanes = numLanes;
ue.road.laneWidth_m = laneWidth;
ue.road.boundaryMode = string(cfg.mobility.boundaryMode);

%% -------------------------
% 8) Summary statistics
%% -------------------------
ue.summary.nominalSpeed_kmh = speed_kmh;
ue.summary.meanAssignedSpeed_kmh = mean(ue.speed_kmh);
ue.summary.stdAssignedSpeed_kmh = std(ue.speed_kmh);
ue.summary.directionMode = string(cfg.mobility.directionMode);
ue.summary.layoutType = 'RoadCorridor2D';

end