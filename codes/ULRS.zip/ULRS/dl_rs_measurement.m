function measState = dl_rs_measurement(cfg, bs, ue, measState, ueX, ueY, shadowState, fastState, t)
%DL_RS_MEASUREMENT Generate UE-side DL-RS measurements from all BSs
%
% Revised baseline version:
%   - supports dedicated DL measurement periodicity
%   - supports dedicated DL filtering factor
%   - keeps sample-and-hold behavior
%
% This function is intentionally similar to ul_srs_measurement(), but it
% models conventional UE-side DL measurements for the baseline.

%% -------------------------
% 1) Basic parameters
%% -------------------------
K = ue.numUE;
N = bs.numBS;

ueX = ueX(:);
ueY = ueY(:);

if numel(ueX) ~= K || numel(ueY) ~= K
    error('ueX and ueY must have length K = ue.numUE.');
end

% Dedicated DL measurement period
if isfield(cfg, 'dl') && isfield(cfg.dl, 'measPeriod_s')
    Tmeas_s = cfg.dl.measPeriod_s;
else
    Tmeas_s = cfg.srs.periodicity_s;
end

% Dedicated DL filter alpha
if isfield(cfg, 'dl') && isfield(cfg.dl, 'filterAlpha')
    dlAlpha = cfg.dl.filterAlpha;
else
    dlAlpha = cfg.srs.emaAlpha;
end

filterType = lower(string(cfg.srs.filterType));
measNoiseStd_dB = cfg.channel.measNoiseStd_dB;

enableBeamGain = cfg.channel.enableBeamGain;
beamGainMean_dB = cfg.channel.beamGainMean_dB;
beamGainStd_dB = cfg.channel.beamGainStd_dB;
beamUpdatePeriod_s = cfg.channel.beamUpdatePeriod_s;

% DL transmit powers
defaultDlPtx_dBm = 46.0;
if isfield(cfg, 'bs') && isfield(cfg.bs, 'txPower_dBm')
    defaultDlPtx_dBm = cfg.bs.txPower_dBm;
end

lteDlPtx_dBm = defaultDlPtx_dBm;
nrDlPtx_dBm = defaultDlPtx_dBm;

if isfield(cfg.radio, 'lteDlTxPower_dBm')
    lteDlPtx_dBm = cfg.radio.lteDlTxPower_dBm;
end
if isfield(cfg.radio, 'nrDlTxPower_dBm')
    nrDlPtx_dBm = cfg.radio.nrDlTxPower_dBm;
end

%% -------------------------
% 2) Initialization
%% -------------------------
if isempty(measState)
    measState.raw_dBm = -inf(K, N);
    measState.filt_dBm = -inf(K, N);
    measState.lastValid_dBm = -inf(K, N);

    measState.lastMeasTime_s = -inf(K,1);
    measState.numMeas = zeros(K,1);

    measState.beamGain_dB = zeros(K,N);
    measState.lastBeamUpdate_s = -inf;

    measState.initialized = true;
end

%% -------------------------
% 3) Validate state inputs
%% -------------------------
if ~isfield(shadowState, 'value_dB') || ~isequal(size(shadowState.value_dB), [K, N])
    error('shadowState.value_dB must have size [K x N].');
end

if ~isfield(fastState, 'value_dB') || ~isequal(size(fastState.value_dB), [K, N])
    error('fastState.value_dB must have size [K x N].');
end

%% -------------------------
% 4) Update beam-gain abstraction
%% -------------------------
if enableBeamGain && (t - measState.lastBeamUpdate_s >= beamUpdatePeriod_s)
    measState.lastBeamUpdate_s = t;
    measState.beamGain_dB = beamGainMean_dB + beamGainStd_dB * randn(K, N);
elseif ~enableBeamGain
    measState.beamGain_dB = zeros(K, N);
end

%% -------------------------
% 5) Determine which UEs perform measurements now
%% -------------------------
doMeas = (t - measState.lastMeasTime_s) >= Tmeas_s;
idxUE = find(doMeas).';

if isempty(idxUE)
    return;
end

measState.lastMeasTime_s(doMeas) = t;
measState.numMeas(doMeas) = measState.numMeas(doMeas) + 1;

%% -------------------------
% 6) Generate fresh raw DL measurements
%% -------------------------
Xshadow_dB = shadowState.value_dB;
Ffast_dB = fastState.value_dB;
Gbeam_dB = measState.beamGain_dB;

for k = idxUE
    for b = 1:N
        dx = bs.x(b) - ueX(k);
        dy = bs.y(b) - ueY(k);
        d2D_m = sqrt(dx^2 + dy^2);

        rat_b = upper(string(bs.rat(b)));
        switch rat_b
            case "NR"
                PL_dB = pathloss_nr_uma(d2D_m, cfg);
                Ptx_dBm = nrDlPtx_dBm;
            case "LTE"
                PL_dB = pathloss_lte_uma(d2D_m, cfg);
                Ptx_dBm = lteDlPtx_dBm;
            otherwise
                error('Unsupported BS RAT label: %s', rat_b);
        end

        Nmeas_dB = measNoiseStd_dB * randn();

        measState.raw_dBm(k,b) = ...
            Ptx_dBm ...
            - PL_dB ...
            - Xshadow_dB(k,b) ...
            + Ffast_dB(k,b) ...
            + Gbeam_dB(k,b) ...
            + Nmeas_dB;
    end
end

%% -------------------------
% 7) Filter fresh measurements
%% -------------------------
switch filterType
    case "ema"
        alpha = dlAlpha;

        for k = idxUE
            oldFilt = measState.filt_dBm(k,:);
            rawNow  = measState.raw_dBm(k,:);

            noPrev = isinf(oldFilt);
            newFilt = oldFilt;

            newFilt(noPrev) = rawNow(noPrev);
            newFilt(~noPrev) = alpha * rawNow(~noPrev) + (1 - alpha) * oldFilt(~noPrev);

            measState.filt_dBm(k,:) = newFilt;
        end

    case "moving_average"
        L = max(1, cfg.srs.movingAvgLength);
        beta = 1 / L;

        for k = idxUE
            oldFilt = measState.filt_dBm(k,:);
            rawNow  = measState.raw_dBm(k,:);

            noPrev = isinf(oldFilt);
            newFilt = oldFilt;

            newFilt(noPrev) = rawNow(noPrev);
            newFilt(~noPrev) = beta * rawNow(~noPrev) + (1 - beta) * oldFilt(~noPrev);

            measState.filt_dBm(k,:) = newFilt;
        end

    otherwise
        error('Unsupported cfg.srs.filterType: %s', cfg.srs.filterType);
end

%% -------------------------
% 8) Update sample-and-hold state
%% -------------------------
measState.lastValid_dBm(idxUE,:) = measState.filt_dBm(idxUE,:);

end