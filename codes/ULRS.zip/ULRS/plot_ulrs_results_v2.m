function plot_ulrs_results_v2(results, cfg)

x = results.speed_kmh;

figure;
errorbar(x, results.mean.HOProbability, results.std.HOProbability, '-o', 'LineWidth', 1.4);
grid on;
xlabel('UE speed [km/h]');
ylabel('HO probability');
title(['UL-RS: HO probability vs speed (' cfg.scenario.name ')']);

figure;
errorbar(x, results.mean.meanHOCount, results.std.meanHOCount, '-o', 'LineWidth', 1.4);
grid on;
xlabel('UE speed [km/h]');
ylabel('Mean successful HO count per UE');
title(['UL-RS: Mean HO count vs speed (' cfg.scenario.name ')']);

figure;
errorbar(x, results.mean.outageProbability, results.std.outageProbability, '-o', 'LineWidth', 1.4);
grid on;
xlabel('UE speed [km/h]');
ylabel('Outage probability');
title(['UL-RS: Outage probability vs speed (' cfg.scenario.name ')']);

figure;
errorbar(x, results.mean.HOsPerMCSim, results.std.HOsPerMCSim, '-o', 'LineWidth', 1.4);
grid on;
xlabel('UE speed [km/h]');
ylabel('Successful HOs / Monte Carlo simulation');
title(['UL-RS: HOs per MC simulation vs speed (' cfg.scenario.name ')']);

end