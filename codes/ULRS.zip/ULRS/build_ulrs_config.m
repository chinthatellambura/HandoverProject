function cfg = build_ulrs_config(scenario)
%BUILD_ULRS_CONFIG Build scenario-driven configuration for UL-RS and DL comparison

%% General simulation
cfg.sim.seed = 1;
cfg.sim.Tsim = 30.0;
cfg.sim.dt = 0.01;
cfg.sim.Nt = floor(cfg.sim.Tsim / cfg.sim.dt);

cfg.scenario.name = sprintf('ULRS_%s_to_%s_%s', ...
    scenario.servingType, scenario.candidateType, scenario.environment);
cfg.scenario.description = cfg.scenario.name;
cfg.scenario.environment = scenario.environment;
cfg.scenario.servingType = scenario.servingType;
cfg.scenario.candidateType = scenario.candidateType;

%% UE settings
cfg.ue.numUE = 20;
cfg.ue.txPower_dBm = 23.0;
cfg.ue.txPower_W = 10.^((cfg.ue.txPower_dBm - 30)/10);
cfg.ue.height_m = 1.5;

%% Corridor geometry
cfg.layout.roadLength_m = 3000;
cfg.layout.roadWidth_m = 12;
cfg.layout.numLanes = 2;
cfg.layout.numBS = 8;
cfg.layout.bsOffsetY_m = 35;

%% Mobility
cfg.mobility.defaultSpeed_kmh = 30;
cfg.mobility.speedStd_kmh = 2.0;
cfg.mobility.directionMode = 'bidirectional';
cfg.mobility.boundaryMode = 'reflect';
cfg.mobility.speedSet_kmh = [3 10 20 30 50 70 90];

%% Shared HO timing
cfg.ho.A3offset_dB = 3.0;
cfg.ho.TTT_s = 0.08;

cfg.ho.prepDelay_s = 0.04;
cfg.ho.execDelay_s = 0.04;
cfg.ho.attachDelay_s = 0.02;
cfg.ho.totalExecutionDelay_s = ...
    cfg.ho.prepDelay_s + cfg.ho.execDelay_s + cfg.ho.attachDelay_s;

%% Outage / target thresholds
cfg.outage.minServingULRSRP_dBm = -105.0;
cfg.outage.minTargetULRSRP_dBm  = -102.0;
cfg.ho.minTargetULRSRP_dBm      = -102.0;
cfg.ho.minTargetDLRSRP_dBm      = -102.0;

%% UL-RS settings
cfg.srs.periodicity_s = 0.02;
cfg.srs.periodicitySet_s = [0.01 0.02 0.04 0.08];
cfg.srs.burstDuration_s = 0.001;
cfg.srs.filterType = 'ema';
cfg.srs.emaAlpha = 0.4;
cfg.srs.movingAvgLength = 3;

%% DL baseline settings
cfg.dl.measPeriod_s    = 0.04;
cfg.dl.reportDelay_s   = 0.03;
cfg.dl.decisionDelay_s = 0.01;
cfg.dl.filterAlpha     = 0.25;

%% Channel defaults
cfg.channel.enableLOSModel = false;
cfg.channel.forceLOS = false;
cfg.channel.shadowingStd_dB = 4.0;
cfg.channel.shadowCorrDist_m = 25.0;
cfg.channel.fastFadingStd_dB = 1.5;
cfg.channel.fastFadingCorrTime_s = 0.05;
cfg.channel.measNoiseStd_dB = 1.0;
cfg.channel.enableBeamGain = true;
cfg.channel.beamGainMean_dB = 6.0;
cfg.channel.beamGainStd_dB = 2.0;
cfg.channel.beamUpdatePeriod_s = 0.08;

%% Monte Carlo
cfg.mc.numSeeds = 10;
cfg.mc.seedList = 1:cfg.mc.numSeeds;

%% Plot
cfg.plot.saveFigures = false;
cfg.plot.outputDir = 'results';
cfg.plot.figureFormat = 'png';

%% Scenario-dependent radio / deployment settings
cfg.serving = localTypeProfile(scenario.servingType);
cfg.candidate = localTypeProfile(scenario.candidateType);

% Shared BS defaults
cfg.bs.height_m = 25.0;
cfg.bs.txPower_dBm = max(cfg.serving.bsTxPower_dBm, cfg.candidate.bsTxPower_dBm);

% DL explicit powers
cfg.radio.lteDlTxPower_dBm = 46.0;
cfg.radio.nrDlTxPower_dBm  = 46.0;

% UL / carrier defaults used by pathloss modules
cfg.radio.fcGHz = 3.5;       % fallback
cfg.radio.lteFcGHz = 2.0;
cfg.radio.nrFcGHz  = 3.5;

% Geometry tuning from scenario mix
cfg.layout.interSiteDistance_m = max(cfg.serving.interSiteDistance_m, cfg.candidate.interSiteDistance_m);

% RAT/domain-specific beamforming
if strcmp(cfg.serving.rat,'LTE') && strcmp(cfg.candidate.rat,'LTE')
    cfg.channel.enableBeamGain = false;
    cfg.channel.beamGainMean_dB = 0;
    cfg.channel.beamGainStd_dB = 0;
end

end

function p = localTypeProfile(typeName)
switch upper(string(typeName))
    case "NR_PUBLIC"
        p.rat = 'NR';
        p.domain = 'public';
        p.fcGHz = 3.5;
        p.bsTxPower_dBm = 46.0;
        p.interSiteDistance_m = 650;
    case "NR_PRIVATE"
        p.rat = 'NR';
        p.domain = 'private';
        p.fcGHz = 3.7;
        p.bsTxPower_dBm = 43.0;
        p.interSiteDistance_m = 500;
    case "LTE"
        p.rat = 'LTE';
        p.domain = 'public';
        p.fcGHz = 2.0;
        p.bsTxPower_dBm = 46.0;
        p.interSiteDistance_m = 800;
    otherwise
        error('Unsupported scenario type: %s', typeName);
end
end