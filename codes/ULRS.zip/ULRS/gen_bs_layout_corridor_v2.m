function bs = gen_bs_layout_corridor_v2(cfg)
%GEN_BS_LAYOUT_CORRIDOR_V2 Mixed-domain BS layout for scenario-driven simulations

N = cfg.layout.numBS;
roadLen = cfg.layout.roadLength_m;
bsOffsetY = cfg.layout.bsOffsetY_m;
hBS = cfg.bs.height_m;

% Use common spacing over full corridor
isd = cfg.layout.interSiteDistance_m;

totalSpan = (N - 1) * isd;
xStart = max(0, 0.5 * (roadLen - totalSpan));
xCoords = xStart + (0:N-1) * isd;

yCoords = zeros(1, N);
for i = 1:N
    if mod(i,2)==1
        yCoords(i) = +bsOffsetY;
    else
        yCoords(i) = -bsOffsetY;
    end
end

zCoords = hBS * ones(1, N);

bs.numBS = N;
bs.x = xCoords(:);
bs.y = yCoords(:);
bs.z = zCoords(:);
bs.id = (1:N).';

bs.name = strings(N,1);
bs.rat = strings(N,1);
bs.domain = strings(N,1);
bs.fcGHz = zeros(N,1);
bs.txPower_dBm = zeros(N,1);

midX = roadLen/2;

for i = 1:N
    if bs.x(i) <= midX
        prof = cfg.serving;
    else
        prof = cfg.candidate;
    end

    bs.name(i) = sprintf('BS_%02d', i);
    bs.rat(i) = string(prof.rat);
    bs.domain(i) = string(prof.domain);
    bs.fcGHz(i) = prof.fcGHz;
    bs.txPower_dBm(i) = prof.bsTxPower_dBm;
end

bs.road.xMin = 0;
bs.road.xMax = roadLen;
bs.road.yMin = -0.5 * cfg.layout.roadWidth_m;
bs.road.yMax = +0.5 * cfg.layout.roadWidth_m;

end