function results = run_sweep_speed(cfg)
%RUN_SWEEP_SPEED Monte Carlo speed sweep for UL-RS handover simulator
%
%   results = RUN_SWEEP_SPEED(cfg)
%
% Input:
%   cfg      : configuration struct
%
% Output:
%   results  : struct containing speed-sweep KPI results
%
% Description:
%   This function performs the first report-facing experiment for the
%   revised UL RS simulator. It sweeps UE speed across the configured speed
%   set, runs multiple Monte Carlo seeds per speed, and computes averaged
%   values for the primary KPIs:
%
%       1) Handover probability
%       2) Mean handover count
%       3) Outage probability
%
%   It also stores auxiliary statistics such as handover success rate,
%   handover failure rate, and handover attempts, which are useful for
%   debugging and for later report expansion.
%
% Notes:
%   - This function uses main_ulrs_single_run() as the simulation engine.
%   - The current version is intended for the NR->NR scenario, but the same
%     structure can later be reused for LTE->NR by providing the
%     appropriate configuration file.
%   - Results are averaged over cfg.mc.seedList.

%% -------------------------
% 1) Read sweep settings
%% -------------------------
speedSet_kmh = cfg.mobility.speedSet_kmh(:);
numSpeeds = numel(speedSet_kmh);

seedList = cfg.mc.seedList(:);
numSeeds = numel(seedList);

if numSpeeds < 1
    error('cfg.mobility.speedSet_kmh must contain at least one speed.');
end
if numSeeds < 1
    error('cfg.mc.seedList must contain at least one seed.');
end

%% -------------------------
% 2) Preallocate result storage
%% -------------------------
HOProbability_runs   = nan(numSpeeds, numSeeds);
meanHOCount_runs     = nan(numSpeeds, numSeeds);
outageProbability_runs = nan(numSpeeds, numSeeds);

meanHOAttempts_runs  = nan(numSpeeds, numSeeds);
HOSuccessRate_runs   = nan(numSpeeds, numSeeds);
HOFailureRate_runs   = nan(numSpeeds, numSeeds);

% Optionally keep one representative simOut per speed
repSimOut = cell(numSpeeds,1);

%% -------------------------
% 3) Sweep over speeds and seeds
%% -------------------------
for i = 1:numSpeeds
    speed_kmh = speedSet_kmh(i);

    fprintf('Running speed sweep: %g km/h (%d/%d)\n', ...
        speed_kmh, i, numSpeeds);

    for j = 1:numSeeds
        seed = seedList(j);

        [kpi, simOut] = main_ulrs_single_run(cfg, speed_kmh, seed);

        HOProbability_runs(i,j)     = kpi.HOProbability;
        meanHOCount_runs(i,j)       = kpi.meanHOCount;
        outageProbability_runs(i,j) = kpi.outageProbability;

        meanHOAttempts_runs(i,j)    = kpi.meanHOAttempts;
        HOSuccessRate_runs(i,j)     = kpi.HOSuccessRate;
        HOFailureRate_runs(i,j)     = kpi.HOFailureRate;

        % Store first seed as representative output for this speed
        if j == 1
            repSimOut{i} = simOut;
        end
    end
end

%% -------------------------
% 4) Aggregate across seeds
%% -------------------------
results = struct();

results.speed_kmh = speedSet_kmh;
results.numSeeds = numSeeds;
results.seedList = seedList;

% Mean values
results.mean.HOProbability      = mean(HOProbability_runs, 2, 'omitnan');
results.mean.meanHOCount        = mean(meanHOCount_runs, 2, 'omitnan');
results.mean.outageProbability  = mean(outageProbability_runs, 2, 'omitnan');

results.mean.meanHOAttempts     = mean(meanHOAttempts_runs, 2, 'omitnan');
results.mean.HOSuccessRate      = mean(HOSuccessRate_runs, 2, 'omitnan');
results.mean.HOFailureRate      = mean(HOFailureRate_runs, 2, 'omitnan');

% Standard deviations across seeds
results.std.HOProbability       = std(HOProbability_runs, 0, 2, 'omitnan');
results.std.meanHOCount         = std(meanHOCount_runs, 0, 2, 'omitnan');
results.std.outageProbability   = std(outageProbability_runs, 0, 2, 'omitnan');

results.std.meanHOAttempts      = std(meanHOAttempts_runs, 0, 2, 'omitnan');
results.std.HOSuccessRate       = std(HOSuccessRate_runs, 0, 2, 'omitnan');
results.std.HOFailureRate       = std(HOFailureRate_runs, 0, 2, 'omitnan');

% Raw run matrices
results.raw.HOProbability_runs      = HOProbability_runs;
results.raw.meanHOCount_runs        = meanHOCount_runs;
results.raw.outageProbability_runs  = outageProbability_runs;

results.raw.meanHOAttempts_runs     = meanHOAttempts_runs;
results.raw.HOSuccessRate_runs      = HOSuccessRate_runs;
results.raw.HOFailureRate_runs      = HOFailureRate_runs;

% Representative sim outputs
results.repSimOut = repSimOut;

% Metadata
results.meta.scenarioName = cfg.scenario.name;
results.meta.description = cfg.scenario.description;
results.meta.numSpeeds = numSpeeds;
results.meta.kpiList = {'HOProbability', 'meanHOCount', 'outageProbability'};

end