function [execState, servingBS, outageState] = ho_execution_ulrs( ...
    cfg, bs, ue, execState, outageState, servingBS, measMatrix_dBm, hoState, t)
%HO_EXECUTION_ULRS Execute UL-RS-triggered handovers and track outage
%
%   [execState, servingBS, outageState] = HO_EXECUTION_ULRS( ...
%       cfg, bs, ue, execState, outageState, servingBS, ...
%       measMatrix_dBm, hoState, t)
%
% Inputs:
%   cfg            : configuration struct
%   bs             : BS struct
%   ue             : UE struct
%   execState      : execution-state struct; if empty, initializes
%   outageState    : outage-state struct; if empty, initializes
%   servingBS      : [K x 1] current serving BS index per UE
%   measMatrix_dBm : [K x N] current filtered UL measurement matrix
%   hoState        : decision-state struct from ho_decision_ulrs_a3()
%   t              : current simulation time [s]
%
% Outputs:
%   execState      : updated execution-state struct
%   servingBS      : updated serving BS indices
%   outageState    : updated outage-state struct
%
% Description:
%   This function models a simplified finite-duration HO execution process.
%   Once the decision module triggers a HO for a UE, the UE enters an
%   execution phase that lasts for:
%
%       T_exec,total = T_prep + T_exec + T_attach
%
%   During this execution window:
%       - the source serving BS remains the old serving cell,
%       - the target BS is tracked as a pending HO target,
%       - outage is accumulated if neither the serving link nor the target
%         link is usable.
%
%   At the end of the execution window:
%       - if the target link is usable, the HO is declared successful and
%         servingBS is switched to the target BS;
%       - otherwise the HO is declared failed and the serving cell remains
%         unchanged.
%
% Notes:
%   - This is a system-level execution abstraction, not full signaling.
%   - It is intentionally compatible with later comparison to L1/L2
%     triggered mobility.
%   - Outage is accumulated continuously in time, not just as an event.
%
% Execution state fields:
%   .isExecuting        [K x 1] logical
%   .sourceBS           [K x 1]
%   .targetBS           [K x 1]
%   .startTime_s        [K x 1]
%   .endTime_s          [K x 1]
%   .numStarted         [K x 1]
%   .numSuccess         [K x 1]
%   .numFailure         [K x 1]
%   .completedNow       [K x 1] logical
%   .successNow         [K x 1] logical
%   .failureNow         [K x 1] logical
%
% Outage state fields:
%   .isOutageNow        [K x 1] logical
%   .timeInOutage_s     [K x 1]
%   .numOutageSamples   [K x 1]
%   .initialized        logical

%% -------------------------
% 1) Dimensions and parameters
%% -------------------------
K = ue.numUE;
N = bs.numBS;
dt = cfg.sim.dt;

if ~isequal(size(measMatrix_dBm), [K, N])
    error('measMatrix_dBm must have size [K x N].');
end

servingBS = servingBS(:);
if numel(servingBS) ~= K
    error('servingBS must have length K.');
end

Ttotal_s = cfg.ho.totalExecutionDelay_s;
minServ_dBm = cfg.outage.minServingULRSRP_dBm;
minTgt_dBm  = cfg.outage.minTargetULRSRP_dBm;

%% -------------------------
% 2) Initialize execution state
%% -------------------------
if isempty(execState)
    execState.isExecuting   = false(K,1);
    execState.sourceBS      = zeros(K,1);
    execState.targetBS      = zeros(K,1);
    execState.startTime_s   = nan(K,1);
    execState.endTime_s     = nan(K,1);

    execState.numStarted    = zeros(K,1);
    execState.numSuccess    = zeros(K,1);
    execState.numFailure    = zeros(K,1);

    execState.completedNow  = false(K,1);
    execState.successNow    = false(K,1);
    execState.failureNow    = false(K,1);

    execState.initialized   = true;
end

%% -------------------------
% 3) Initialize outage state
%% -------------------------
if isempty(outageState)
    outageState.isOutageNow      = false(K,1);
    outageState.timeInOutage_s   = zeros(K,1);
    outageState.numOutageSamples = zeros(K,1);
    outageState.initialized      = true;
end

%% -------------------------
% 4) Reset one-step output flags
%% -------------------------
execState.completedNow(:) = false;
execState.successNow(:)   = false;
execState.failureNow(:)   = false;
outageState.isOutageNow(:)= false;

%% -------------------------
% 5) Start new HO executions where triggered
%% -------------------------
for k = 1:K
    if hoState.triggeredNow(k)
        % Do not overwrite an ongoing HO for the same UE
        if ~execState.isExecuting(k)
            tgt = hoState.targetBS(k);
            src = servingBS(k);

            if tgt >= 1 && tgt <= N && src >= 1 && src <= N && tgt ~= src
                execState.isExecuting(k) = true;
                execState.sourceBS(k)    = src;
                execState.targetBS(k)    = tgt;
                execState.startTime_s(k) = t;
                execState.endTime_s(k)   = t + Ttotal_s;
                execState.numStarted(k)  = execState.numStarted(k) + 1;
            end
        end
    end
end

%% -------------------------
% 6) Update outage during execution / normal service
%% -------------------------
for k = 1:K
    if execState.isExecuting(k)
        s = execState.sourceBS(k);
        c = execState.targetBS(k);

        Ms = measMatrix_dBm(k, s);
        Mc = measMatrix_dBm(k, c);

        % During execution, outage occurs if neither old serving nor target
        % is usable enough to sustain connectivity / complete HO.
        inOutage = (Ms < minServ_dBm) && (Mc < minTgt_dBm);

    else
        s = servingBS(k);
        Ms = measMatrix_dBm(k, s);

        % Outside execution, outage occurs if the serving link is unusable.
        inOutage = (Ms < minServ_dBm);
    end

    outageState.isOutageNow(k) = inOutage;

    if inOutage
        outageState.timeInOutage_s(k) = outageState.timeInOutage_s(k) + dt;
        outageState.numOutageSamples(k) = outageState.numOutageSamples(k) + 1;
    end
end

%% -------------------------
% 7) Complete HO executions whose end time has been reached
%% -------------------------
for k = 1:K
    if execState.isExecuting(k) && (t >= execState.endTime_s(k))
        tgt = execState.targetBS(k);

        Mtgt = measMatrix_dBm(k, tgt);

        % Completion success rule:
        % target must still be usable at completion time
        if isfinite(Mtgt) && (Mtgt >= minTgt_dBm)
            servingBS(k) = tgt;
            execState.numSuccess(k) = execState.numSuccess(k) + 1;
            execState.successNow(k) = true;
        else
            execState.numFailure(k) = execState.numFailure(k) + 1;
            execState.failureNow(k) = true;
        end

        execState.completedNow(k) = true;

        % Clear execution state
        execState.isExecuting(k) = false;
        execState.sourceBS(k)    = 0;
        execState.targetBS(k)    = 0;
        execState.startTime_s(k) = nan;
        execState.endTime_s(k)   = nan;
    end
end

end