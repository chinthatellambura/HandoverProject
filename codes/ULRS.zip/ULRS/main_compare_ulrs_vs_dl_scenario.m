%% MAIN SCRIPT: Scenario-driven UL-RS vs DL comparison
clear; clc; close all;

fprintf('=============================================\n');
fprintf(' Scenario-Driven UL-RS vs DL Baseline Compare\n');
fprintf('=============================================\n');

disp('Select serving-side domain:');
disp('  1 = 5G public');
disp('  2 = 5G private');
disp('  3 = 4G');
servChoice = input('Enter serving-side option: ');

disp('Select candidate-side domain:');
disp('  1 = 5G public');
disp('  2 = 5G private');
disp('  3 = 4G');
candChoice = input('Enter candidate-side option: ');

scenario = struct();
scenario.servingType = mapScenarioType(servChoice);
scenario.candidateType = mapScenarioType(candChoice);
scenario.environment = 'UMa';

cfg = build_ulrs_config(scenario);

cfg.plot.saveFigures = false;
cfg.plot.outputDir = 'results';
cfg.mc.numSeeds = 1000;
cfg.mc.seedList = 1:cfg.mc.numSeeds;
cfg.mobility.speedSet_kmh = [3 10 20 30 50 70 90];

fprintf('\nRunning UL-RS proposed method...\n');
resultsUL = run_sweep_speed_ulrs_v2(cfg);

fprintf('\nRunning DL baseline...\n');
resultsDL = run_sweep_speed_dl_v2(cfg);

plot_compare_ulrs_vs_dl_v2(resultsUL, resultsDL, cfg);

save('ulrs_vs_dl_scenario_results.mat', 'cfg', 'resultsUL', 'resultsDL', 'scenario');

fprintf('\nSaved results to ulrs_vs_dl_scenario_results.mat\n');

function s = mapScenarioType(code)
switch code
    case 1
        s = 'NR_public';
    case 2
        s = 'NR_private';
    case 3
        s = 'LTE';
    otherwise
        error('Invalid scenario option.');
end
end