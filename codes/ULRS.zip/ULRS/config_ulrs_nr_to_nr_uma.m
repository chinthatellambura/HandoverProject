function cfg = config_ulrs_nr_to_nr_uma()
%CONFIG_ULRS_NR_TO_NR_UMA Configuration for UL-RS HO simulation
% Scenario: NR -> NR, Urban Macro, Road/Highway Corridor
%
% This function centralizes all simulation assumptions so that topology,
% channel, measurement, handover, and KPI modules can use a common
% parameter structure.

%% =========================
% 1) General simulation setup
%% =========================
cfg.sim.seed = 1;                 % random seed
cfg.sim.Tsim = 30.0;              % total simulation time [s]
cfg.sim.dt = 0.01;                % simulation time step [s]
cfg.sim.Nt = floor(cfg.sim.Tsim / cfg.sim.dt);

%% =========================
% 2) Scenario identity
%% =========================
cfg.scenario.name = 'ULRS_NR_to_NR_UMA';
cfg.scenario.description = ...
    'UL RS-based HO, NR-to-NR, Urban Macro, road corridor';
cfg.scenario.sourceRAT = 'NR';
cfg.scenario.targetRAT = 'NR';
cfg.scenario.environment = 'UMa';
cfg.scenario.layout = 'RoadCorridor2D';

%% =========================
% 3) Carrier and radio parameters
%% =========================
cfg.radio.fcGHz = 3.5;            % carrier frequency [GHz]
cfg.radio.bandwidthMHz = 100;     % nominal channel bandwidth [MHz]

% UE uplink power
cfg.ue.txPower_dBm = 23.0;        % UE UL transmit power [dBm]
cfg.ue.txPower_W = 10.^((cfg.ue.txPower_dBm - 30)/10);

% Heights
cfg.bs.height_m = 25.0;           % gNB antenna height [m]
cfg.ue.height_m = 1.5;            % UE antenna height [m]

%% =========================
% 4) Deployment geometry: road corridor
%% =========================
cfg.layout.roadLength_m = 3000;   % total road length [m]
cfg.layout.roadWidth_m = 12;      % road width [m]
cfg.layout.numLanes = 2;          % optional descriptor

% Urban macro corridor deployment
cfg.layout.numBS = 7;             % number of gNBs
cfg.layout.interSiteDistance_m = 500;  % BS spacing along corridor [m]
cfg.layout.bsOffsetY_m = 35;      % lateral offset from road center [m]

% BS coordinates are generated later by topology function

%% =========================
% 5) UE population and mobility
%% =========================
cfg.ue.numUE = 20;

% Speed sweep for report figures [km/h]
cfg.mobility.speedSet_kmh = [3 10 20 30 50 70 90];

% Internal speed setting for a single run; overwritten by sweep scripts
cfg.mobility.defaultSpeed_kmh = 30;

% Direction along corridor
cfg.mobility.directionMode = 'bidirectional'; % 'forward', 'backward', 'bidirectional'

% Small random speed variation around each scenario speed
cfg.mobility.speedStd_kmh = 2.0;

% Reflect or terminate when reaching boundary
cfg.mobility.boundaryMode = 'reflect'; % 'reflect' or 'clamp'

%% =========================
% 6) UL SRS configuration
%% =========================
cfg.srs.periodicity_s = 0.02;     % default SRS periodicity [s]
cfg.srs.periodicitySet_s = [0.01 0.02 0.04 0.08 0.16];
cfg.srs.burstDuration_s = 0.001;  % SRS burst duration [s]

% Measurement filtering
cfg.srs.filterType = 'ema';       % 'ema' or 'moving_average'
cfg.srs.emaAlpha = 0.4;           % exponential smoothing factor
cfg.srs.movingAvgLength = 3;      % used only if moving_average selected

%% =========================
% 7) Handover control parameters
%% =========================
cfg.ho.A3offset_dB = 3.0;         % UL A3-like offset [dB]
cfg.ho.TTT_s = 0.08;              % time-to-trigger [s]

% Candidate usability threshold
cfg.ho.minTargetULRSRP_dBm = -110.0;

% Execution timing abstraction
cfg.ho.prepDelay_s = 0.020;       % target preparation delay [s]
cfg.ho.execDelay_s = 0.020;       % switch execution delay [s]
cfg.ho.attachDelay_s = 0.010;     % target access/attach delay [s]

% Total execution window
cfg.ho.totalExecutionDelay_s = ...
    cfg.ho.prepDelay_s + cfg.ho.execDelay_s + cfg.ho.attachDelay_s;

%% =========================
% 8) Outage model parameters
%% =========================
cfg.outage.minServingULRSRP_dBm = -115.0; % serving link unusable below this
cfg.outage.minTargetULRSRP_dBm = -110.0;  % target unusable below this

%% =========================
% 9) Propagation model parameters
%% =========================
% 3GPP-inspired UMa abstraction; exact formulas implemented elsewhere.
cfg.channel.modelName = 'NR_UMa';

% LOS / NLOS handling
cfg.channel.enableLOSModel = false;  % first revision: use one UMa abstraction
cfg.channel.forceLOS = false;

% Shadowing
cfg.channel.shadowingStd_dB = 4.0;
cfg.channel.shadowCorrDist_m = 25.0;

% Fast variation abstraction
cfg.channel.fastFadingStd_dB = 1.5;
cfg.channel.fastFadingCorrTime_s = 0.05;

% Measurement noise
cfg.channel.measNoiseStd_dB = 1.0;

% NR beamforming abstraction
cfg.channel.enableBeamGain = true;
cfg.channel.beamGainMean_dB = 6.0;
cfg.channel.beamGainStd_dB = 2.0;
cfg.channel.beamUpdatePeriod_s = 0.08;

%% =========================
% 10) Monte Carlo settings
%% =========================
cfg.mc.numSeeds = 20;             % number of random seeds for averaging
cfg.mc.seedList = 1:cfg.mc.numSeeds;

%% =========================
% 11) KPI options
%% =========================
cfg.kpi.enableHOProbability = true;
cfg.kpi.enableHOCount = true;
cfg.kpi.enableOutageProbability = true;

cfg.kpi.trackAuxiliary = true;    % keep extra stats for debugging/reporting

%% =========================
% 12) Plot options
%% =========================
cfg.plot.saveFigures = false;
cfg.plot.outputDir = 'results';
cfg.plot.figureFormat = 'png';

end