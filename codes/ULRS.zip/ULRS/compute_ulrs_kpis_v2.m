function kpi = compute_ulrs_kpis_v2(cfg, ue, execState, outageState)
%COMPUTE_ULRS_KPIS_V2 KPIs including HOs per MC simulation

K = ue.numUE;
Tsim = cfg.sim.Tsim;

numStarted = execState.numStarted(:);
numSuccess = execState.numSuccess(:);
numFailure = execState.numFailure(:);
timeInOutage_s = outageState.timeInOutage_s(:);

hadAtLeastOneHO = (numSuccess >= 1);
outageFractionPerUE = timeInOutage_s / Tsim;

P_HO = mean(hadAtLeastOneHO);
meanHOCount = mean(numSuccess);
P_out = sum(timeInOutage_s) / (K * Tsim);

totalAttempts = sum(numStarted);
totalSuccess = sum(numSuccess);
totalFailure = sum(numFailure);

if totalAttempts > 0
    HOSR = totalSuccess / totalAttempts;
    HOFR = totalFailure / totalAttempts;
else
    HOSR = NaN;
    HOFR = NaN;
end

% New metric:
% number of successful HOs / number of MC simulations
% For a single run, this is just total successful HOs in this run.
HOsPerMCSim = totalSuccess;

kpi = struct();
kpi.HOProbability = P_HO;
kpi.meanHOCount = meanHOCount;
kpi.outageProbability = P_out;
kpi.HOSuccessRate = HOSR;
kpi.HOFailureRate = HOFR;
kpi.totalHOSuccess = totalSuccess;
kpi.HOsPerMCSim = HOsPerMCSim;

kpi.perUE.hadAtLeastOneHO = hadAtLeastOneHO;
kpi.perUE.numHOSuccess = numSuccess;
kpi.perUE.outageFraction = outageFractionPerUE;

end