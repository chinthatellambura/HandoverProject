function PL_dB = pathloss_nr_uma(d2D_m, cfg)
%PATHLOSS_NR_UMA 3GPP-inspired NR Urban Macro pathloss model
%
%   PL_dB = PATHLOSS_NR_UMA(d2D_m, cfg)
%
% Inputs:
%   d2D_m : 2D distance(s) between UE and BS in meters
%           Can be scalar, vector, or matrix.
%   cfg   : configuration struct from config_ulrs_nr_to_nr_uma()
%
% Output:
%   PL_dB : pathloss in dB, same size as d2D_m
%
% Description:
%   This function implements a standards-inspired NR Urban Macro (UMa)
%   pathloss abstraction suitable for system-level simulation. It is not a
%   full geometry-based stochastic channel model, but it captures the main
%   dependencies on:
%       - carrier frequency,
%       - BS/UE heights,
%       - 2D/3D separation,
%       - LOS / NLOS regime selection.
%
%   For the first revision, the function supports:
%       1) forced LOS,
%       2) forced NLOS,
%       3) probabilistic LOS selection based on distance.
%
% Notes:
%   - This function is intended for system-level mobility evaluation.
%   - It is deliberately lightweight and modular.
%   - A minimum link distance is enforced to avoid nonphysical singularities.
%
% Assumptions:
%   - Carrier frequency is read from cfg.radio.fcGHz
%   - BS/UE heights are read from cfg.bs.height_m and cfg.ue.height_m
%   - LOS/NLOS selection is controlled by cfg.channel.enableLOSModel and
%     cfg.channel.forceLOS
%
% Reference style:
%   The formulas are based on a 3GPP-inspired Urban Macro abstraction for
%   NR system-level studies, adapted here for lightweight MATLAB mobility
%   simulation.

%% -------------------------
% 1) Read parameters
%% -------------------------
fc_GHz = cfg.radio.fcGHz;
hBS = cfg.bs.height_m;
hUE = cfg.ue.height_m;

enableLOSModel = cfg.channel.enableLOSModel;
forceLOS = cfg.channel.forceLOS;

% Optional override for forcing NLOS in future extensions
forceNLOS = false;
if isfield(cfg.channel, 'forceNLOS')
    forceNLOS = cfg.channel.forceNLOS;
end

%% -------------------------
% 2) Distance sanitization
%% -------------------------
d2D_m = max(d2D_m, 10);  % enforce minimum distance for model stability
d3D_m = sqrt(d2D_m.^2 + (hBS - hUE).^2);

%% -------------------------
% 3) LOS probability model
%% -------------------------
% Lightweight UMa LOS probability abstraction.
%
% For d2D <= 18 m, LOS probability is 1.
% Beyond that, use a decreasing distance-based probability.
%
% This keeps the model simple but more realistic than a single deterministic
% pathloss law.

if forceLOS && forceNLOS
    error('Both forceLOS and forceNLOS cannot be true simultaneously.');
end

if forceLOS
    isLOS = true(size(d2D_m));
elseif forceNLOS
    isLOS = false(size(d2D_m));
elseif enableLOSModel
    pLOS = ones(size(d2D_m));

    idxFar = d2D_m > 18;
    dFar = d2D_m(idxFar);

    pLOS(idxFar) = (18 ./ dFar) + exp(-dFar / 63) .* (1 - 18 ./ dFar);
    pLOS = min(max(pLOS, 0), 1);

    isLOS = rand(size(d2D_m)) < pLOS;
else
    % First-revision default if LOS model disabled:
    % use a single UMa abstraction. Conservative choice: NLOS.
    isLOS = false(size(d2D_m));
end

%% -------------------------
% 4) Breakpoint distance
%% -------------------------
% Simplified breakpoint distance for UMa-type model.
dBP = 4 * hBS * hUE * (fc_GHz * 1e9) / 3e8;  % [m]

%% -------------------------
% 5) LOS pathloss
%% -------------------------
PL_LOS = zeros(size(d2D_m));

idx1 = d2D_m <= dBP;
idx2 = d2D_m > dBP;

% LOS segment 1
PL_LOS(idx1) = 28.0 + 22*log10(d3D_m(idx1)) + 20*log10(fc_GHz);

% LOS segment 2
PL_LOS(idx2) = 28.0 + 40*log10(d3D_m(idx2)) + 20*log10(fc_GHz) ...
    - 9*log10(dBP^2 + (hBS - hUE)^2);

%% -------------------------
% 6) NLOS pathloss
%% -------------------------
PL_NLOS_raw = 13.54 + 39.08*log10(d3D_m) + 20*log10(fc_GHz) ...
    - 0.6*(hUE - 1.5);

% In 3GPP-style models, NLOS pathloss should not be lower than LOS
PL_NLOS = max(PL_LOS, PL_NLOS_raw);

%% -------------------------
% 7) Select final regime
%% -------------------------
PL_dB = PL_NLOS;
PL_dB(isLOS) = PL_LOS(isLOS);

end