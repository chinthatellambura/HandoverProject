function servingBS = select_serving_bs_initial_v2(cfg, bs, measMatrix_dBm, ueX, ueY)
%SELECT_SERVING_BS_INITIAL_V2 Initial serving selection restricted to serving-side domain

[K, N] = size(measMatrix_dBm);

ueX = ueX(:);
ueY = ueY(:);
servingBS = zeros(K,1);

servingRat = upper(string(cfg.serving.rat));
servingDomain = lower(string(cfg.serving.domain));

eligibleMask = false(K, N);
for b = 1:N
    eligibleMask(:,b) = ...
        (upper(string(bs.rat(b))) == servingRat) & ...
        (lower(string(bs.domain(b))) == servingDomain);
end

for k = 1:K
    validMask = eligibleMask(k,:) & isfinite(measMatrix_dBm(k,:));

    if any(validMask)
        vals = measMatrix_dBm(k,:);
        vals(~validMask) = -inf;
        [~, idx] = max(vals);
        servingBS(k) = idx;
    else
        d2D = inf(1,N);
        for b = 1:N
            if eligibleMask(k,b)
                dx = bs.x(b) - ueX(k);
                dy = bs.y(b) - ueY(k);
                d2D(b) = sqrt(dx^2 + dy^2);
            end
        end
        [~, idx] = min(d2D);
        servingBS(k) = idx;
    end
end

end